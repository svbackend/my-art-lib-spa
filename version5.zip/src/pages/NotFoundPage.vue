<template>
  <div class="not-found">
    404 NOT FOUND
  </div>
</template>
