import env from '../.env.json';
export const apiHost = env.baseUrl;
